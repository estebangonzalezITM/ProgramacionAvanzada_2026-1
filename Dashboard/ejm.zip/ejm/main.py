import writer as wf
import numpy as np
import plotly.graph_objs as go
import plotly.express as px

# This is a placeholder to get you started or refresh your memory.
# Delete it or adapt it as necessary.
# Documentation is available at https://dev.writer.com/framework

# Shows in the log when the app starts
print("Hello world!")

# Its name starts with _, so this function won't be exposed
def _update_message(state):
    is_even = state["counter"] % 2 == 0
    message = ("+Even" if is_even else "-Odd")
    state["message"] = message

def decrement(state):
    state["counter"] -= 1
    _update_message(state)

def increment(state):
    state["counter"] += 1
    # Shows in the log when the event handler is run
    print("The counter has been incremented.")
    _update_message(state)
    
# Initialise the state

# "_my_private_element" won't be serialised or sent to the frontend,
# because it starts with an underscore

initial_state = wf.init_state({
    "my_app": {
        "title": "MY APP"
    },
    "_my_private_element": 1337,
    "message": None,
    "counter": 26,
    "freq":1,
    "Ampl":1,
    "figura1": None,
    "offset": 0,
})

_update_message(initial_state)

xx = np.linspace(-2*np.pi,2*np.pi,500)

def move_slider(state):
    yy = state["Ampl"]*np.sin(xx*state["freq"]) + state["offset"]
    fig = px.scatter(x = xx,  y = yy , range_y=[-2, 2])
    fig.update_traces(marker=dict(color='red'))
    state["figura1"] = fig


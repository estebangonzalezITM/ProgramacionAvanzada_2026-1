import writer as wf
import numpy as np
import plotly.graph_objs as go
import plotly.express as px
import numpy as np
import pandas as pd

# This is a placeholder to get you started or refresh your memory.
# Delete it or adapt it as necessary.
# Documentation is available at https://dev.writer.com/framework

# Shows in the log when the app starts
print("Hello world!")

# Its name starts with _, so this function won't be exposed
def _update_message(state):
    is_even = state["counter"] % 2 == 0
    message = ("+Even" if is_even else "-Odd")
    state["message"] = message

def decrement(state):
    state["counter"] -= 1
    _update_message(state)

def increment(state):
    state["counter"] += 1
    # Shows in the log when the event handler is run
    print("The counter has been incremented.")
    _update_message(state)

t = np.linspace(0,10,1000)

def move_slider(state):
    #print('f =', state["freq"])
    f = state["freq"]
    A = state["Amp"]
    yy = A*np.sin(2*np.pi*t*f)
    fig = px.line(x = t,  y = yy )
    fig.update_yaxes(range=[-5, 5])
    state["figure1"] = fig

def ing_num(state):
    f = state["freq2"]
    yy = np.sin(2*np.pi*t*f)
    zz = np.cos(2*np.pi*t*f)
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=t, y=yy, mode='lines', name='Sin(x)'))
    fig.add_trace(go.Scatter(x=t, y=zz, mode='markers', name='Cos(x)'))
    state["figure2"] = fig

# Initialise the state

# "_my_private_element" won't be serialised or sent to the frontend,
# because it starts with an underscore

initial_state = wf.init_state({
    "my_app": {
        "title": "MI APLICACION"
    },
    "_my_private_element": 1337,
    "message": None,
    "counter": 30,
    "freq":1,
    "figure1": None,
    "figure2": None,
    "Amp": 1,
    "freq2":1,
})

_update_message(initial_state)

data = pd.read_csv("01_Power_consumption.csv")